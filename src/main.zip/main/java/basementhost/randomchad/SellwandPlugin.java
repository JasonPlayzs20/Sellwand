package basementhost.randomchad;

import org.bukkit.plugin.java.JavaPlugin;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public final class SellwandPlugin extends JavaPlugin {
	@Override
	public void onEnable() {
		getLogger().info("Sellwand plugin is enabled");
	}
	@Override
	public void onDisable() {
		getLogger().info("Sellwand plugin is disabled");
	}
}